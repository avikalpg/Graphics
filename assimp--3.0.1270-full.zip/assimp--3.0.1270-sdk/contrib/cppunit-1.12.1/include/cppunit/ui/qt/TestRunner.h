// //////////////////////////////////////////////////////////////////////////
// Header file TestRunner.h for class TestRunner
// (c)Copyright 2000, Baptiste Lepilleur.
// Created: 2001/09/19
// //////////////////////////////////////////////////////////////////////////
#ifndef CPPUNIT_QTUI_TESTRUNNER_H
#define CPPUNIT_QTUI_TESTRUNNER_H

#include <cppunit/ui/qt/QtTestRunner.h>

#endif  // CPPUNIT_QTUI_TESTRUNNER_H
